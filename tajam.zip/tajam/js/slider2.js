var secondSliderModel = {
    leftButton: document.querySelector('.control-left'),
    rightButton: document.querySelector('.control-right'),

    masPictures: document.querySelectorAll('.control-pictures__img'),
    masSlides: document.querySelectorAll('.slide-people'),
    masIdx: [1,2,3,4,5],

    change: function(direction){
        secondSliderView.resetSlider(this.masPictures, this.masSlides, this.masIdx);
        if( direction === "forward" ){
            var tempIdx = this.masIdx.pop();
            this.masIdx.unshift(tempIdx);
        }
        if( direction === "back" ){
            var tempIdx = this.masIdx.shift();
            this.masIdx.push(tempIdx);
        }
        secondSliderView.setSlider(this.masIdx, this.masPictures, this.masSlides);
    }
}
var secondSliderView = {
    resetSlider: function(masPict, masSlides, masIdx){
        for( var i = 0; i < masPict.length; i++ ){
            masPict[i].classList.remove('control-pictures__img' + masIdx[i]);
            masSlides[i].classList.remove('show');
        }
    },
    setSlider: function(idx, masPict, masSlides){
        for( var i = 0; i < masPict.length; i++ ){
            masPict[i].classList.add('control-pictures__img' + idx[i]);
            masSlides[(idx[2])-1].classList.add('show');
        }
    }
}
var secondSliderController = {
    changeSlide: function(direction){
        secondSliderModel.change(direction);
    }
}               