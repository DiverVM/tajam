var modelSlider = {
    buttons: document.querySelectorAll('.slider-button'),
    slides: document.querySelectorAll('.slide'),
    currentButton: function(temp){
        for( var i = 0; i < this.buttons.length; i++ ){
            if( this.buttons[i] === temp ){
                return i;
            }
        }
    },
    clickButton: function(temp){
        var currentButtonIndex = this.currentButton(temp);
        viewSlider.setSlide(this.buttons, this.slides, currentButtonIndex);
    }
}
var viewSlider = {
    resetSlider: function(buttons, slides){
        for( var i = 0; i < buttons.length; i++ ){
            buttons[i].classList.remove('checked');
            slides[i].classList.remove('show');
        }
    },
    setSlide: function(masBut, masSlide, curIdx){
        this.resetSlider(masBut, masSlide);
        masBut[curIdx].classList.add('checked');
        masSlide[curIdx].classList.add('show');
    },

}
var controllerSlider = {
    changeSlide: function(curBut){
        modelSlider.clickButton(curBut);
    }
}