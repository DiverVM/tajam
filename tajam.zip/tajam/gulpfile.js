var gulp = require('gulp');
var autoprefixer = require('gulp-autoprefixer');
var uglify = require('gulp-uglify');
var minify = require('gulp-minify-css');
var concat = require('gulp-concat');
var less = require('gulp-less');
var path = require('path');
 
gulp.task('prefix', function () {
    return gulp.src('css/**/*.css')
        .pipe(autoprefixer({
            browsers: ['last 10 versions'],
            cascade: false
        }))
        .pipe(gulp.dest('css'));
});
gulp.task('js', function(){
   gulp.src('js/*.js')
   .pipe(concat('js.min.js'))
   .pipe(uglify())
   .pipe(gulp.dest('js'));
});
gulp.task('css', function(){
   gulp.src('css/*.css')
   .pipe(concat('style.min.css'))
   .pipe(minify())
   .pipe(gulp.dest('./css'));
});
gulp.task('less', function () {
  return gulp.src('./less/**/*.less')
    .pipe(less({
      paths: [ path.join(__dirname, 'less', 'includes') ]
    }))
    .pipe(gulp.dest('./css'));
});